/// Timmy's Chores  
/// Zach Broadbent, Brandon McCrave, Ryan Seely
/// CSc 110 fall 2023

import java.util.Scanner;

public class Main {
  static final String WELCOME_MESSAGE = "Welcome to Timmy's Chores! Type help for game directions.";
  static final String HELP_MESSAGE = " Move in directions North, South, East, and West. Your job is to complete the chores! Your first task is to get dressed in Timmy's Closet. After that you need to grab the dishes from the dining room. You then want to go to the basement so you could get the sponge and gas. After that you can now go to the kitchen, wash the dishes and go to the backyard and mow the lawn. Once you do all of that you can go to the front door and go outside! Good luck! ";

  // Mom's anger tracker
  static int momsAnger = 0;

  // The number assignments for all the rooms
  static final int START_ROOM = 0;
  static final int PROGRAM_ERROR = -1;
  static final int TIMMYS_ROOM = 0;
  static final int FRONT_DOOR = 2;
  static final int TIMMYS_CLOSET = 3;
  static final int KITCHEN = 4;
  static final int FOYER = 5;
  static final int LIVING_ROOM = 6;
  static final int SUN_ROOM = 7;
  static final int DINING_ROOM = 8;
  static final int BASEMENT = 9;
  static final int BACKYARD = 10;
  static final int TIMMYS_BATHROOM = 11;

  // The number assignments for all the chores
  static boolean[] choreTrack = new boolean[6]; // booleans to track chore progess
  static final int GET_DRESSED = 0;
  static final int GET_DISHES = 1;
  static final int GET_SPONGE = 2;
  static final int CLEAN_DISHES = 3;
  static final int GRAB_GAS = 4;
  static final int FUEL_LAWNMOWER = 5;

  static Scanner scanner;
  static boolean done = false; // Indicates if the game is done or not

  public static void main(String[] args) {
    scanner = new Scanner(System.in);// Creating a scanner object to read from stdin.
    System.out.println(WELCOME_MESSAGE);
    int currentRoom = START_ROOM; // Track where Timmy currently is

    while (!done) {
      currentRoom = processRoom(currentRoom);
      processMomsAnger();
    }
  }

  // Print out a prompt and get the response ALL in lower case
  static String getResponse(String message) {
    System.out.println(message);
    return scanner.nextLine().toLowerCase();
  }

  // Process Mom's Anger (based on the values achieved)
  static void processMomsAnger() {
    momsAnger++; // One move down
    switch (momsAnger) {
      case 2:
        System.out.println("You hear your mom's voice in the distance...");
        break;
      case 4:
        System.out.println("You hear Mom: Timmy have you done all your chores yet?");
        break;
      case 10:
        if (!choreTrack[CLEAN_DISHES]) {
          System.out.println("You hear your Mom scream: TIMMY! Why haven't you done the dishes yet?");
        }
        break;
    }
  }

  // Process the current room and invoke the appropriate room function
  // Return the new room where Timmy enters
  static int processRoom(int currentRoom) {
    switch (currentRoom) {
      case TIMMYS_ROOM:
        return inRoomTimmy();
      case TIMMYS_CLOSET:
        return inRoomTimmysCloset();
      case FOYER:
        return inRoomFoyer();
      case LIVING_ROOM:
        return inRoomLivingRoom();
      case SUN_ROOM:
        return inRoomSunRoom();
      case BASEMENT:
        return inRoomBasement();
      case BACKYARD:
        return inRoomBackyard();
      case DINING_ROOM:
        return inRoomDiningRoom();
      case KITCHEN:
        return inRoomKitchen();
      case TIMMYS_BATHROOM:
        return inRoomTimmysBathroom();

      case PROGRAM_ERROR:
      default:
        System.out.println("Error in program. Incomplete code?");
        done = true; // Stops the game
        return PROGRAM_ERROR;
    }
  }

  // Process and handle actions in Timmy's room
  static int inRoomTimmy() {
    System.out.println("You are in Timmy's room. ");
    if (!choreTrack[GET_DRESSED]) {
      System.out.println("You should go to your closet to get dressed.");
    } else {
      // No need to display any additional information.
    }

    String cmd = getResponse("What do you want to do?");
    switch (cmd) {
      // logic for determining which directions are able to be moved in and which are
      // not.
      case "go east":
        System.out.println("You walk into your closet.");
        return TIMMYS_CLOSET;

      case "go west":
        if (!choreTrack[GET_DRESSED]) {
          System.out.println("You haven't got dressed yet.");
          return TIMMYS_ROOM;// Return the same room
        } else {
          System.out.println("You head to the foyer, probably clad in today's fresh clothes.");
          return FOYER;
        }
      case "go south":
        if (!choreTrack[GET_DRESSED]) {
          System.out.println("You haven't got dressed yet.");
          return TIMMYS_ROOM;// Return the same room
        } else {
          System.out.println("You head to the Living Room.");
          return LIVING_ROOM;
        }
      case "go north":
        System.out.println("You go north and enter the bathroom. How lovely");
        return TIMMYS_BATHROOM; // Return the same room

      case "help":
        System.out.println(HELP_MESSAGE);

        return TIMMYS_ROOM; // Return the same room
      default:
        System.out.println("Sorry, I don't understand.");
        return TIMMYS_ROOM;
    }
  }

  static int inRoomTimmysBathroom() {
    System.out.println("You have entered your bathroom, yikes you need some fabreeze. ");
    String cmd = getResponse("What do you want to do? ");
    switch (cmd) {
      // logic for determining which directions are able to be moved in and which are
      // not.
      case "go east":
        System.out.println("Oh no you bump into the dirty toilet.");
        return TIMMYS_BATHROOM; // Return the room name

      case "go west":
        System.out.println("You look at yourself in the mirror");
        return TIMMYS_BATHROOM;// Return the room name

      case "go south":
        System.out.println("You go back to your room.");
        return TIMMYS_ROOM; // Return the same room

      case "go north":
        System.out.println("You look out the window, such a nice day to mow the lawn.");
        return TIMMYS_BATHROOM; // Return the same room

      default:
        System.out.println("Sorry, I don't understand.");
        return TIMMYS_BATHROOM;
    }
  }

  // Process and handle actions in Timmy's Closet
  static int inRoomTimmysCloset() {
    System.out.println("You are in your closet. woo its really dark in here.");
    String cmd = getResponse("What do you want to do?");
    switch (cmd) {
      // logic for determining which directions are able to be moved in and which are
      // not.
      case "go east":
        System.out.println("You can't go east. There seems to be a rack of clothes in your way.");
        return TIMMYS_CLOSET; // Return the same room

      case "go west":
        System.out.println("You leave the closet.");
        return TIMMYS_ROOM;// Return the same room

      case "go south":
        System.out.println("You can't go south. There seems to be a wall there.");
        return TIMMYS_CLOSET; // Return the same room

      case "go north":
        System.out.println("You can't go north. There seems to be a wall there.");
        return TIMMYS_CLOSET; // Return the same room

      case "get dressed":
        if (!choreTrack[GET_DRESSED]) {
          System.out.println("You pull out a pair of sweats and a t-shirt and some comfy socks.");
          choreTrack[GET_DRESSED] = true;
          return TIMMYS_CLOSET;
        } else {
          System.out.println("You are already dressed. Do you want to do more laundry?");
          return TIMMYS_CLOSET;
        }
      case "help":
        System.out.println(HELP_MESSAGE);
        return TIMMYS_CLOSET; // Return player to Timmy's Closet

      default:
        System.out.println("Sorry, I don't understand.");
        return TIMMYS_CLOSET; // Return player to Timmy's Closet
    }
  }

  // Process and handle actions in the Living Room

  static int inRoomLivingRoom() {
    System.out.println("You are in the living room, a sweet scent of air freshener wafts through the air. ");
    String cmd = getResponse("What do you want to do?");
    switch (cmd) {
      // logic for determining which directions are able to be moved in and which are
      // not.
      case "go east":
        System.out.println("You walk into a WALL.");
        return LIVING_ROOM; // Returns player to the dining room

      case "go west":
        System.out.println("You enter the Dining room and see all the dirty dishes on the table.");
        return DINING_ROOM;// Returns player to the same room

      case "go south":
        System.out.println("You enter the Sun Room, Oh boy the grass is getting long! .");
        return SUN_ROOM; // Returns player to the sun room

      case "go north":
        System.out.println("You go back to your room");
        return TIMMYS_ROOM; // Returns player to Timmy's room

      case "help":
        System.out.println(HELP_MESSAGE);
        return SUN_ROOM; // Return the same room

      default:
        System.out.println("Sorry, I don't understand.");
        return LIVING_ROOM; // Return player to the Living Room
    }
  }

  static int inRoomFoyer() {
    System.out.println("You are in the foyer room.");
    String cmd = getResponse("What do you want to do?");
    switch (cmd) {
      // logic for determining which directions are able to be moved in and which are
      // not.
      case "go east":
        System.out.println("You head back into your room.");
        return TIMMYS_ROOM; // Return player to Timmys room

      case "go west":
        System.out.println("You walked into a window.");
        return FOYER;// Return player to the Foyer

      case "go south":
        System.out.println("You walk into the Dining Room.");
        return DINING_ROOM; // Return player to the Dining room

      case "go north":
        if (choreTrack[CLEAN_DISHES] && choreTrack[GET_SPONGE] && choreTrack[GET_DISHES] && choreTrack[GET_DRESSED]
            && choreTrack[GRAB_GAS] && choreTrack[FUEL_LAWNMOWER]) {
          done = true;
          System.out.println("You have completed all of the chores! Congratulations!");
          // Return the corresponding room here or any other relevant action
        } else {
          System.out.println("You haven't done all of the chores yet, try again.");
        }
        return FOYER; // Returns player to the Foyer

      case "help":
        System.out.println(HELP_MESSAGE);
        return FOYER; // Return player to the Foyer

      default:
        System.out.println("Sorry, I don't understand.");
        return FOYER; // Return player to the Foyer
    }

  }

  static int inRoomSunRoom() {
    System.out.println(
        "You are in the Sun room and see the sun shining through the windows.  The grass looks very long from here.");
    String cmd = getResponse("What do you want to do?");
    switch (cmd) {
      // logic for determining which directions are able to be moved in and which are
      // not.
      case "go east":
        System.out.println("You head down the creaky stairs into the basement.");
        return BASEMENT; // Returns player to the Basement

      case "go west":
        System.out.println(
            "You knock your head into the screen wall, you think to yourself, it's a beautiful day, you should get outside.");
        return SUN_ROOM;// Return player to the Sun Room

      case "go south":
        System.out.println("You slide the screen door open and head into the backyard.");
        return BACKYARD; // Return player to the Backyard

      case "go north":
        System.out.println("You go back into the living room.");
        return LIVING_ROOM; // Return player to the Living Room

      case "help":
        System.out.println(HELP_MESSAGE);
        return SUN_ROOM; // Return player to the Sun Room

      default:
        System.out.println("Sorry, I don't understand.");
        return SUN_ROOM; // Return player to the Sun Room
    }
  }

  static int inRoomBasement() {
    System.out.println(
        "Your are in the basement. You should probably grab the gas and sponge.");
    String cmd = getResponse("What do you want to do?");
    switch (cmd) {
      // logic for determining which directions are able to be moved in and which are
      // not.
      case "go east":
        System.out.println("You walked into a wall.");
        return BASEMENT; // Returns player to the Basement

      case "go west":
        System.out.println(
            "You head back up to the sun room.");
        return SUN_ROOM;// Return the Sun room

      case "go south":
        System.out.println("You walked into a wall.");
        return BASEMENT; // Returns player to the Basement

      case "go north":
        System.out.println("You walked into a wall.");
        return BASEMENT; // Returns player to the Basement

      case "get sponge":
        if (!choreTrack[GET_SPONGE]) {
          System.out.println("You grab a sponge off of the shelf.");
          choreTrack[GET_SPONGE] = true;
          return BASEMENT; // Return player to Basement
        } else {
          System.out.println("You already grabbed the sponge, but if you want another thats okay.");
          return BASEMENT; // Return player to Basement
        }

      case "grab gas":
        if (!choreTrack[GRAB_GAS]) {
          System.out.println("You grab the gas canister.  Don't spill it");
          choreTrack[GRAB_GAS] = true;
          return BASEMENT; // Return player to Basement
        } else {
          System.out.println("You already grabbed the gas there is no more to grab.");
          return BASEMENT; // Return player to Basement
        }

      case "help":
        System.out.println(HELP_MESSAGE);
        return BASEMENT; // Return player to the Basement

      default:
        System.out.println("Sorry, I don't understand.");
        return BASEMENT; // Returns player to the Basement
    }
  }

  static int inRoomBackyard() {
    System.out.println("You are in the backyard.");
    String cmd = getResponse("What do you want to do?");
    switch (cmd) {
      // logic for determining which directions are able to be moved in and which are
      // not.
      case "go east":
        System.out.println("You walked into a fence.");
        return BACKYARD; // Returns player to the Backyard

      case "go west":
        System.out.println(
            "You walked into a fence.");
        return BACKYARD;// Returns player to the Backyard

      case "go south":
        System.out.println("You walked into a fence.");
        return BACKYARD; // Returns player to the Backyard

      case "go north":
        System.out.println("You head back into the Sun room.");
        return SUN_ROOM; // Returns player to the Sun room

      case "fuel lawn mower":
        if (!choreTrack[GRAB_GAS]) {
          System.out.println("You need to grab gas to fuel the lawn mower with gas");
          return BACKYARD; // Return player to the Backyard
        } else {
          System.out.println("You put gas in the lawnmower.  You mow da lawn and da grass looks very pretty.");
          choreTrack[FUEL_LAWNMOWER] = true;
          return BACKYARD; // Return player to Backyard
        }

      case "help":
        System.out.println(HELP_MESSAGE);
        return BACKYARD; // Returns player to the Backyard

      default:
        System.out.println("Sorry, I don't understand.");
        return BACKYARD; // Returns player to the Backyard;
    }

  }

  static int inRoomDiningRoom() {
    System.out.println("You are in the dining room.");
    String cmd = getResponse("What do you want to do?");
    switch (cmd) {
      // logic for determining which directions are able to be moved in and which are
      // not.
      case "go east":
        System.out.println("You head back to the living room.");
        return LIVING_ROOM; // Returns player to the Living room

      case "go west":
        System.out.println(
            "You head into the kitchen.");
        return KITCHEN;// Returns player to the Kitchen

      case "go south":
        System.out.println("You walked into a wall.");
        return DINING_ROOM; // Returns player to the Dining room

      case "go north":
        System.out.println("You walk into the foyer.");
        return FOYER; // Returns player to the Foyer

      case "get dishes":
        if (!choreTrack[GET_DISHES]) {
          System.out.println("You grab all of the dirty dishes.");
          choreTrack[GET_DISHES] = true;
          return KITCHEN; // Return player to Kitchen;
        } else {
          System.out.println("There are no more dishes to grab.");
          return DINING_ROOM; // Return player to Dining room ;
        }

      case "help":
        System.out.println(HELP_MESSAGE);
        return DINING_ROOM; // Returns the player to the Dining room

      default:
        System.out.println("Sorry, I don't understand.");
        return DINING_ROOM; // Returns player to the
    }
  }

  static int inRoomKitchen() {
    System.out.println("You are in the Kitchen.");
    String cmd = getResponse("What do you want to do?");
    switch (cmd) {
      // logic for determining which directions are able to be moved in and which are
      // not.
      case "go east":
        System.out.println("You head back to the Dining room.");
        return DINING_ROOM; // Returns player to the Dining room

      case "go west":
        System.out.println(
            "You hit your head on a cabinet.");
        return KITCHEN;// Returns player to the Kitchen

      case "go south":
        System.out.println("You hit your head on a cabinet.");
        return KITCHEN; // Returns player to the Kitchen

      case "go north":
        System.out.println("You hit your head on a cabinet.");
        return KITCHEN; // Returns player to the Kitchen

      case "help":
        System.out.println(HELP_MESSAGE);
        return KITCHEN; // Returns player to the Kitchen

      case "clean dishes":
        if ((!choreTrack[GET_DISHES]) && (!choreTrack[GET_SPONGE])) {
          System.out.println("You need to grab the dishes and the sponge first.");
          return KITCHEN; // Returns player to the Kitchen;
        } else {
          System.out.println("These dishes can't get any cleaner! ");
          choreTrack[CLEAN_DISHES] = true;
          return KITCHEN; // Returns player to the Kitchen; ;
        }

      default:
        System.out.println("Sorry, I don't understand.");
        return KITCHEN; // Returns player to the Kitchen;
    }
  }

  static int inRoomFrontDoor() {
    System.out.println("You are in the front door, Congratulations, you have escaped the house!");

    if (choreTrack[CLEAN_DISHES] && choreTrack[GET_SPONGE] && choreTrack[GET_DISHES] && choreTrack[GET_DRESSED]
        && choreTrack[GRAB_GAS] && choreTrack[FUEL_LAWNMOWER]) {
      done = true;
      System.out.println("You have completed all of the chores! Congratulations!");
      // Return the corresponding room here or any other relevant action
    } else {
      System.out.println("You haven't done all of the chores yet, try again.");
      return FOYER; // Returns player to the Foyer
    }
    return FOYER;
  }
}

// boolean allChore = false; ///defined boolean variables
// boolean clothes = false;
// boolean gasCan = false;
// boolean sponge = false;